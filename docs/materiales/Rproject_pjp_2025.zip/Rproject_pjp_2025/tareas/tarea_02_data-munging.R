#- TAREA 02: -------------------------------------------------------------------

#- Objetivo: trabajar unos datos con dplyr para entender sus funciones y aprender a manejar datos con R
#- Seguimos trabajando con datos de población de los municipios españoles extraídos del Padrón del INE
#- los datos están en: https://github.com/perezp44/pjpv.datos.01/raw/master/data/pob_muni_1996_2020.rda

#- lo primero es descargar los datos en la carpeta "./pruebas/"
my_url <- "https://github.com/perezp44/pjpv.datos.01/raw/master/data/pob_muni_1996_2020.rda"
archivo_de_destino <- here::here("pruebas", "pob_muni_1996_2020.rda")
download.file(my_url, archivo_de_destino)


#- importamos los datos a R (al Global env.)
archivo_de_destino <- here::here("pruebas", "pob_muni_1996_2020.rda")
df <- rio::import(archivo_de_destino)   

#- ya podemos trabajar con ellos. ya están en la memoria de R 
#- tenemos los datos en el data.frame "df" trabajaremos sobre df para contestar una serie de preguntas y practicar con dplyr
#- cargamos paquetes que vamos a necesitar
library(tidyverse)


#- antes de hacer nada con unos datos conviene saber un poco que son y su estructura (análisis preliminar)
#- vemos los datos: el df tiene 13 columnas/variables. 
#- Como vemos son datos de población total, hombre y mujeres en los municipios españoles para varios años, de 1996 a 2020
#- con str() vemos la estructura de df:  
str(df)   

#- las 2 primeras columnas parecen numéricas pero son de tipo character, 
#- la tercera (year) es numérica 
#- más adelante veremos mas cosas que hay que hacer con un df antes de empezar a trabajar con ellos


#- TAREA ZERO: (ya está resuelta)
#- ¿Cuantos habitantes había en 2015 en el municipio con nombre "Pancrudo"?
aa <- df %>% 
  filter(ine_muni.n == "Pancrudo") %>%    #- fíjate q la v. ine_muni.n es textual
  filter(year == 2015)                    #-  la v. year es numérica





# 02_1 -------------------------------------------------------------------------
#- Muestra en un data.frame llamado aa los habitantes que tenía tu municipio de nacimiento en los distintos años. 
# Nota: Identificar por nombre siempre es problemático, piensa que el nombre puede estar escrito en castellano o valenciano, inglés, o simplemente mal escrito, o abreviado etc.... 
#- Siempre que sea posible es mejor identificar por código; por ejemplo, para identificar a los estudiantes es mejor el NPA, porque es único, mientras que Pedros puede haber muchos.
# Otra nota: Para identificar de manera única un municipio español son necesarios 2 códigos: el código del municipio y el código de la provincia. En nuestros datos estos dos códigos están juntos en la variable ine_muni. Por ejemplo el municipio de Pancrudo en la provincia de Teruel se identifica de forma única con ine_muni = "44177". Los 2 primeros números corresponden al código provincial: la provincia de Teruel tiene el código 44.
#- Piensa que a lo mejor, tu pueblo no se puede identificar por nombre. Esto pasaría si hubiese otro municipio que se llame igual


str(df)
aa <- df %>% filter(ine_muni.n == "Cariño") #- filtrar por nombre suele ser problemático
aa <- df %>% filter(ine_muni == "15901")    #- siempre es mejor usar códigos (si es q los hay)

#- más información, más cosas (!!!!!!!)
aa <- df %>% filter(ine_muni == 15901)      #- ine_muni es textual  ¿xq funciona ine_muni == 15901?

#- algo parecido ocurre en el siguiente ejemplo
#- lo q ocurre es que cuando llamas a una función para hacer una operación y "==" en realidad es una función
#- la f. trata de hacer la operación que le pides, incluso cambiando el tipo de dato (coerción)
a1 <- "1234"  ;    a2 <- 1234        #- creo a1 (textual) y a2 (númerico)
"1234" == 1234                       #- no son iguales pero `==` nos devuelve que si son iguales (ha hecho coerción)
identical(a1, a2)                    #- la f. identical() nos muestra que claro que no son iguales


# 02_2 -------------------------------------------------------------------------
#- ¿Cuantas provincias diferentes hay en España si las identificamos con la v. ine_prov? (se puede responder a esta pregunta de muuuuuchas formas, incluso preguntándoselo a Alexa o ala Wikipedia y evmos q hay 52 "provincias"

#- empezamos con una solución a la R-base q se ve mucho
#- usa 2 funciones unique() y length()
aa <- length(unique(df$ine_prov.n))  #- solución con R-base (esto se ve bastante)

#- para entender unique():
zz <- c(1, 1, 1, 2, 2, 13, 14)  #- vector con elementos repetidos
(zz <- unique(zz))
#- length() simplemente devuelve el tamaño de un vector: zz ahora tiene 4 elementos 
length(zz)

#- soluciones con tidyverse (hay muchas)
aa <- df %>% distinct(ine_prov)   #- distinct() es similar a unique(), devuelve los valores únicos de un vector(columna)
aa <- df %>% distinct(ine_prov) %>% nrow()    #- finalmente con nrow() contamos las filas: son 52

aa <- df %>% distinct(ine_prov, ine_prov.n)   #- distinct() es útil

#- tb podemos usar count()
aa <- df %>% 
  count(ine_prov, ine_prov.n, ine_ccaa) 

#- tb podemos usar summarise()
aa <- df %>% 
  group_by(ine_prov, ine_prov.n, ine_ccaa) %>% 
  summarise(NN = n()) %>% ungroup()



# 02_3 -------------------------------------------------------------------------
#- muestra las 5 CC.AA que en 2017 tenían más habitantes
#- Nota: al final tendréis que usar la f. slice() pero antes justo antes de usar slice() tendréis que hacer ungroup()
#- también podéis no hacerme caso y tratar de usar slice_max()

aa <- df %>% 
  filter(year == 2017) %>% 
  group_by(ine_ccaa.n) %>%        
  summarise(Pob_CCAA = sum(pob_total, na.rm = TRUE)) %>%   #- cuidado con na.rm = FALSE
  ungroup() %>% 
  arrange(desc(Pob_CCAA)) %>% 
  slice(c(1:5))  #- podríamos usar slice_max(Pob_CCAA, n = 5) y ahorraríamos una linea

#- podemos hacerlo para todos los años y filtrar al final
#- para ello tb hemos de agrupar por año
aa <- df %>%  
  group_by(year, ine_ccaa.n) %>%      #- agrupamos tb x año y al final filtraremos 2017
  summarise(Pob_CCAA = sum(pob_total, na.rm = TRUE)) %>%   #- cuidado con na.rm = FALSE
  slice_max(Pob_CCAA, n = 5) %>%      #- esta vez uso slice_max()
  ungroup() %>% 
  filter(year == 2017)                #- ahora filtro al final



# 02_4 -------------------------------------------------------------------------
#- En 2017, muestre las 10 provincias con mayor número de municipios. 
#- Que se vea tanto el el nombre de la provincia como su código

aa <- df %>% 
  filter(year == 2017) %>% 
  group_by(ine_prov, ine_prov.n) %>%   #- no hace falta agrupar por ine_prov, pero lo prefiero
  summarise(NN = n()) %>% 
  #- la función n() solo funciona dentro de las f. de dplyr: summarise() etc...
  arrange(desc(NN)) %>%  
  ungroup %>% 
  slice(1:10) 


#- de otra forma, con count() y filtrando al final
aa <- df %>% 
  count(year, ine_prov.n, name = "nn_pueblos") %>%  
  group_by(year) %>% 
  slice_max(nn_pueblos , n = 10) %>% 
  filter(year == 2017)




# 02_5 -------------------------------------------------------------------------
#- En 2020, ¿cuantos municipios tenían exactamente el mismo número de mujeres que de hombres?


aa <- df %>% 
  filter(year == 2020) %>% 
  mutate(mujeres_hombres = pob_mujeres - pob_hombres, .after = year) %>% 
  filter(mujeres_hombres == 0) %>% 
  count(ine_prov.n, name = "nn_pueblos") %>% 
  arrange(desc(nn_pueblos))  %>% 
  mutate(NN = sum(nn_pueblos)) %>% 
  mutate(percent =  nn_pueblos/NN)

# 02_6 -------------------------------------------------------------------------
#- Calcula el número de municipios que han habido cada año en España
# Comment: sí, el nº de municipios cambia año a año porque algunos se juntan, otros se separan, ...

aa <- df %>% group_by(year) %>% count

aa <- df %>% count(year) #- en realidad con count() no hace falta agrupar

#-con janitor::tabyl()
#- janitor es un pkg muy útil que veremos más adelante
aa <- df %>% janitor::tabyl(year)
aa <- df %>% janitor::tabyl(ine_prov.n, year)


# 02_7 -------------------------------------------------------------------------
#- En 2020, ¿cuantos municipios habían con el mismo nombre?

aa <- df %>% filter(year == 2020) %>% 
  select(ine_muni.n, ine_prov.n) %>% 
  group_by(ine_muni.n) %>% 
  mutate(NN = n()) %>% 
  filter(NN > 1) %>% 
  arrange(ine_muni.n)


#- solución*** con R-base (!!!!!!!!!!!)
zz <- df[df$year == 2000, c("ine_muni.n")]
zz <- zz[duplicated(zz), ]




# 02_8 -------------------------------------------------------------------------
#- ¿Qué municipio ha visto crecer mas su número de habitantes desde 2000? En esta pregunta, no os hace falta, pero os voy a ayudar un poco, yo lo voy a hacer para mi pueblo, vosotros solo tendréis que modificar el código para que lo haga para todos los municipios
#- es muy parecido a lo q hicimos en clase

#- Solución, pero solo para Pancrudo
df_pancrudo <- df %>% 
  select(year, ine_muni, ine_muni.n, ine_prov.n, pob_total) %>% #- me quedo con 5 variables
  filter(ine_muni.n == "Pancrudo") 

aa <- df_pancrudo %>% 
  filter(year %in% 2000:2020) %>% 
  group_by(ine_muni) %>%  #- no hace falta (xq solo tenemos datos de Pancrudo)
  arrange(year) %>% 
  mutate(crec_pob_1_anyo = pob_total - lag(pob_total)) %>%
  mutate(crec_pob_desde_2000 = pob_total - first(pob_total)) %>%
  mutate(crec_pob_desde_2000_percent = crec_pob_desde_2000 / first(pob_total) *100) %>% 
  #- esta ultima linea solo es para que solo se vean dos decimales en el %
  #- para ellos usamos la función round() de R-base
  mutate(crec_pob_desde_2000_percent = round(crec_pob_desde_2000_percent, digits = 2))


#- ahora ya lo tenéis que hacer vosotros para todos los municipios
#- solo hay que hacer un group_by() por municipio


aa <- df %>% 
  filter(year %in% 2000:2020) %>% 
  select(year, ine_muni, ine_muni.n, ine_prov.n, pob_total) %>%
  group_by(ine_muni, ine_muni.n) %>%  #-  ahora sí hace falta agrupar(auqnue bastaría con ine_muni)
  arrange(year) %>%
  mutate(crec_pob_1_anyo = pob_total - lag(pob_total)) %>%
  mutate(crec_pob_desde_2000 = pob_total - first(pob_total)) %>%
  mutate(crec_pob_desde_2000_percent = crec_pob_desde_2000 / first(pob_total) *100) %>% 
  mutate(crec_pob_desde_2000_percent = round(crec_pob_desde_2000_percent, digits = 2)) %>% 
  ungroup()

#- solo para ver mejor q municipio ha aumentado mas su población
bb <- aa %>% 
  filter(year == 2020) %>% 
  arrange(desc(crec_pob_desde_2000)) %>% 
  select(year, ine_muni.n, ine_prov.n, starts_with("crec_"))

#- solo para ver mejor q municipio ha aumentado mas su población en %

bb <- bb %>% arrange(desc(crec_pob_desde_2000_percent))



# 02_9 -------------------------------------------------------------------------
#- ¿Que municipio ha visto crecer mas, en porcentaje, su población de mujeres desde 2010?
#- podéis reusar el código de  la pregunta anterior. Simplemente tendréis que sustituir algunas cosas: Pob_T por Pob_M  y 2010 por 2000


aa <- df %>% 
  filter(year %in% 2010:2020) %>% 
  select(year, ine_muni, ine_muni.n, ine_prov.n, pob_mujeres) %>%
  group_by(ine_muni) %>%
  arrange(year) %>% 
  mutate(crec_pob_1_anyo = pob_mujeres - lag(pob_mujeres)) %>%
  mutate(crec_pob_desde_2010 = pob_mujeres - first(pob_mujeres)) %>%
  mutate(crec_pob_desde_2010_percent = crec_pob_desde_2010 / first(pob_mujeres) *100) %>% 
  mutate(crec_pob_desde_2010_percent = round(crec_pob_desde_2010_percent, digits = 2)) %>% 
  ungroup()

#- para verlo mejor
bb <- aa %>% 
  filter(year == 2020) %>% 
  arrange(desc(crec_pob_desde_2010)) %>% 
  select(year, ine_muni.n, ine_prov.n, starts_with("crec_"))
#- ahora en %
bb <- bb %>% arrange(desc(crec_pob_desde_2010_percent))






# 02_10 ------------------------------------------------------------------------
#- Muestre como ha evolucionado la diferencia de población entre Madrid y Barcelona a lo largo del tiempo
#- se puede hacer de varias formas pero en este caso prefiero aprovechar la pregunta para practicar con pivot_wider()
#- como quiero que resolváis la pregunta de una determinada manera, os hago yo los primeros pasos


aa <- df %>% filter(ine_muni.n %in% c("Barcelona", "Madrid")) %>% 
  select(c(ine_muni.n, year, pob_total))

#- después de hacer esto, tenéis que pasar "aa" a formato ancho con pivot_wider()

aa_ancho <- aa %>% 
  tidyr::pivot_wider(names_from = ine_muni.n, values_from = pob_total) %>% 
  mutate(dif_M_B = Madrid - Barcelona) %>% arrange(year) %>%
  mutate(crec_dif_M_B = dif_M_B - lag(dif_M_B))  %>%
  mutate(M_como_perc_B = Madrid/Barcelona)




# 02_11 ------------------------------------------------------------------------
#- borra (usando código) todos los archivos que haya en la carpeta "./datos/pruebas/"
my_carpeta <- "./pruebas/"
my_carpeta <- here::here("pruebas")
lista_de_archivos <- fs::dir_ls(my_carpeta)  
fs::file_delete(lista_de_archivos)

#- con R-base (por si no tenéis instalado el paquete "fs")
my_carpeta <- here::here("pruebas")
lista_de_archivos <- list.files(my_carpeta, full.names = TRUE)
file.remove(lista_de_archivos)


