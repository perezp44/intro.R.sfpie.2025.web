#- Seguir trabajando el manejo de datos y practicar la unión de tablas

#- cargamos los datos ----------------------------------------------------------
library(tidyverse)
url_1 <- "https://github.com/perezp44/archivos.download.2023/raw/refs/heads/main/df_pob_mun.rds"

df_pob <- rio::import(url_1) %>% 
  select(year, ine_muni, ine_muni.n, poblacion, pob_values, ine_prov, ine_prov.n)


url_2 <- "https://github.com/perezp44/archivos.download.2023/raw/refs/heads/main/df_bebes_16y19.rds"

df_bebes <- rio::import(url_2) %>% 
  select(year_parto, muni_inscrip, muni_inscrip.n, prov_inscrip, prov_inscrip.n, 
         sexo_bebe, peso_bebe, edad_madre, edad_padre) 

rm(url_1, url_2)


#- Pregunta 1: -----------------------------------------------------------------
#- ¿Que 10 municipios tuvieron una mayor tasa de natalidad en 2019?
#- definimos la tasa de natalidad como: (nº de bebes nacidos/numero de mujeres en el municipio)*1000
#- Pistas: con df_bebes puedes calcular el nº de bebes en cada municipio y en df_pob está el número de mujeres en cada municipio, solo tienes que hacerlo y juntar las tablas y ....




#- Pregunta 2: -----------------------------------------------------------------
#- ¿Que 10 provincias tuvieron una mayor tasa de natalidad en 2019?
#- definimos la tasa de natalidad como: (nº de bebes nacidos/numero de mujeres en el municipio)*1000








#- SOLUCIONES ------------------------------------------------------------------
#- Pregunta 1: -----------------------------------------------------------------
#- ¿Que 10 municipios tuvieron una mayor tasa de natalidad en 2019?
#- definimos la tasa de natalidad como: (nº de bebes nacidos/numero de mujeres en el municipio)*1000
#- Pistas: con df_bebes puedes calcular el nº de bebes en cada municipio y en df_pob está el número de mujeres en cada municipio, solo tienes que hacerlo y juntar las tablas y ....

#- nº de mujeres en cada municipio en 2019
df_pob_M <- df_pob %>% 
  filter(year == 2019) %>% 
  filter(poblacion == "pob_mujeres") %>% 
  select(ine_muni, ine_muni.n, ine_prov.n, pob_values) 

#- bebes totales nacidos en 2019 en cada municipio
df_bebe_T <- df_bebes %>% 
  filter(year_parto == 2019) %>% 
  group_by(muni_inscrip, muni_inscrip.n, prov_inscrip.n) %>% 
  summarise(nn_bebes = n())  %>%     #- tb se puede con count()
  ungroup()

#- salen NAs xq el INE no da los datos de los municipios de menos de 10.000 habitantes
#- quito los NAs (pasará de 803 filas a 753 filas)
df_bebe_T <- df_bebe_T %>% 
  filter(!is.na(muni_inscrip))

#- hemos de juntar las 2 tablas
df <- left_join(df_bebe_T, df_pob_M, by = c("muni_inscrip" = "ine_muni")) %>% 
  select(- muni_inscrip.n, - prov_inscrip.n) %>% 
  dplyr::relocate(nn_bebes, .after = pob_values)

df1 <- left_join(df_bebe_T, df_pob_M, by = join_by("muni_inscrip" == ine_muni)) %>% 
  select(- muni_inscrip.n, - prov_inscrip.n)



#- ahora ya calculamos la tasa de natalidad como: (nº de bebes nacidos/numero de mujeres en el municipio)*1000
df <- df %>% 
  mutate(tasa_natalidad = (nn_bebes / pob_values)*1000, .after = pob_values) %>% 
  arrange(desc(tasa_natalidad))


#--- Empezamos a visualizar ----------------------------------------------------

#- gráfico de barras
df %>% 
  slice_head(n = 10) %>% 
  ggplot(aes(x = reorder(ine_muni.n, tasa_natalidad), y = tasa_natalidad)) +
  geom_col(fill = "orange") +
  coord_flip() +
  labs(title = "Top 10 municipios con mayor tasa de natalidad en 2019", x = "Municipio", y = "Tasa de natalidad") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))



#- un mapa (coropleta)
#- install.packages("mapSpain", dependencies = TRUE)
library(mapSpain)
library(sf)



geometrias_muni <- pjpv.curso.R.2022::LAU2_muni_2020_canarias


geometrias_muni <- esp_get_munic_siane(year = 2019,
                                       epsg = 4326, moveCAN = TRUE,rawcols = TRUE)


names(geometrias_muni) 

df_map <- left_join(geometrias_muni, df, by = c("id_ine" = "muni_inscrip"))

p <- ggplot(df_map, aes(fill = tasa_natalidad)) +
  geom_sf(color = NA) 

p    #- ya lo mejoraremos!!


p + scale_fill_viridis_c(option = "magma")  #- ya lo mejoraremos

#- valencia
df_map %>% 
  filter(ine.ccaa.name == "Comunitat Valenciana") %>% 
  ggplot(aes(fill = tasa_natalidad)) +
  geom_sf(color = NA) + 
  scale_fill_viridis_c(option = "magma") + 
  theme_void() +
  labs(title = "Tasa de natalidad en Valencia", size = 27) +
  #annotate(geom = "text", label = "Valencia", x = -0.4, y = 39.5, size = 4) +
  NULL



#- Pregunta 2: -----------------------------------------------------------------
#- ¿Que 10 provincias tuvieron una mayor tasa de natalidad en 2019?
#- definimos la tasa de natalidad como: (nº de bebes nacidos/numero de mujeres en el municipio)*1000


#- nº de mujeres en cada PROVINCIA en 2019
df_pob_M_prov <- df_pob %>% 
  filter(year == 2019) %>% 
  filter(poblacion == "pob_mujeres") %>% 
  select(pob_values, ine_prov,  ine_prov.n) %>% 
  group_by(ine_prov,  ine_prov.n) %>% 
  summarise(pob_values = sum(pob_values, na.rm = TRUE)) %>%   #- no hace falta na.rm = TRUE, pero ...
  ungroup()


#- bebes totales nacidos en 2019 en cada PROVINCIA:
#- Ya no salen NAs, xq calculamos a nivel provincial, no municipal (el INE solo oculta el municipio de nacimiento, si es municipio pequeño, pero no oculta la provincia de nacimiento)
df_bebe_T_prov <- df_bebes %>% 
  filter(year_parto == 2019) %>% 
  group_by(prov_inscrip, prov_inscrip.n) %>% 
  summarise(nn_bebes = n())  %>%     #- tb se puede con count()
  ungroup()


#- hemos de juntar las 2 tablas
df_prov <- left_join(df_bebe_T_prov, df_pob_M_prov, by = c("prov_inscrip" = "ine_prov")) 

#- ahora ya calculamos la tasa de natalidad como: (nº de bebes nacidos/numero de mujeres en el municipio)*1000
df_prov <- df_prov %>% 
  mutate(tasa_natalidad = (nn_bebes / pob_values)*1000, .after = pob_values) %>% 
  arrange(desc(tasa_natalidad))



#- vamos a visualizarlo --
library(sf)
geometrias <- pjpv.curso.R.2022::LAU2_prov_2020_canarias
rio::export(geometrias, "./datos/LAU2_prov_2020_canarias.rds")

df_map_prov <- left_join(geometrias, df_prov)

p <- ggplot(df_map_prov, aes(fill = tasa_natalidad)) +
  geom_sf(color = "black") 
p

p + scale_fill_viridis_c(option = "plasma") + #- ya lo mejoraremos
  theme_void() +
  labs(title = "Venga a currar!!! \U1F600", size = 30) +
  annotate(geom = "text", 
           label = "A currar!!",
           x = 2.3,
           y = 37,
           size = 6)


