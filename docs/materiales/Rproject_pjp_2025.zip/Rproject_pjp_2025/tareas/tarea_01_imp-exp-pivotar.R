#- TAREA 01: 
#- descarga de datos, importación de datos, manipulación de datos, exportación de datos, borrado de archivos
#- tidyr::pivot_wider(), tidyr::pivot_longer()

# tt_01 ------------------------------------------------------------------------
#- En esta dirección hay unos datos: https://github.com/perezp44/pjpv.datos.01/raw/master/data/pob_muni_1996_2020.rda
#- descarga ese fichero de datos y guárdalo en la siguiente ruta "./pruebas/pob_mun_1996_2020.rda"




# tt_02 ------------------------------------------------------------------------
#- Como vamos a trabajar con los datos que acabas de descargar,
#- ahora tienes que cargar estos en memoria de R, en el Global Environment de R.
#- Por favor, la tabla de datos o data.frame se ha de llamar "df".
#- Os pongo el principio de la instrucción que tenéis que escribir:





# tt_03 ------------------------------------------------------------------------
#- Los datos que has descargado y cargado en  R tienen 13 columnas (variables) y 194.720 filas o registros
#- son datos de población municipal en España
#- Nos vamos a quedar solo con las observaciones de 2 pueblos de Teruel: Pancrudo y Albarracín
#- y para q los datos sean manejables restrinjo la muestra de años a >=2015
#- y como hay muchas columnas me quedo solo con: year, ine_muni.n y pob_total
#- Esto lo hacemos con las siguiente lineas de código:
#- (Recuerda que para poder usar %>%, filter() y select() has de cargar el tidyverse)
#- esta tercera tarea la hago yo 🎉 !!

library(tidyverse)
df_long <- df %>% filter(ine_muni.n %in% c("Pancrudo", "Albarracín")) %>%
  filter(year >= 2015)  %>%
  select(year, ine_muni.n, pob_total)
  



# tt_04 ------------------------------------------------------------------------
#- Como ves, df_long, ahora es mas manejable, tiene sólo 3 columnas y 22 filas (11 para cada pueblo)
#- df_long, ¿está en formato tidy? Sí, está en formato tidy-long, perfecto para los ordenadores,
#- pero nuestro cliente/profesor quiere verlo mejor, quiere que haya una columna con los datos de Pancrudo y otra para Albarracín
#- Él no lo sabe, pero quiere pasar los datos de long a formato ancho o wide.
#- Please, pasa los datos de la columna "pob_total" a formato ancho para que haya una columna para cada pueblo



# tt_05 ------------------------------------------------------------------------
#- haz una tabla o cuadro para visionar los datos. Hazla con el paquete "DT".


# tt_06 ------------------------------------------------------------------------
#- Tenemos que mandarle los datos en formato ancho a nuestro cliente, ademas quiere los datos en formato .xlsx
#- Por favor, exporta esos datos (df_wide) a formato .xlsx. Guarda los datos en "./pruebas/df_wide.xlsx"



# tt_07 ------------------------------------------------------------------------
#- Imagina que han pasado varios días y quieres volver a trabajar con los datos del fichero que mandaste a tu cliente
#- Para simular que han pasado varios dias, vamos a borrar todos los objetos del Gobal Env.
rm(list = ls())
#- Una vez que hemos borrado todos los objetos del Global Env.
#- Por favor, importa al Global env. los datos del fichero que creamos para nuestro cliente





# tt_08 ------------------------------------------------------------------------
#- Bien ya hemos importado los datos del fichero "df_wide.xlsx" pero como vamos a trabajar con esos datos
#- Por favor, transforma los datos de df_wide a formato LONG





# tt_09 ------------------------------------------------------------------------
#- Utiliza los datos en formato LONG para volver a pasarlos a formato ANCHO, pero ...
#- PERO esta vez quiero ver, en lugar de una columna para cada pueblo, ahora quiero ver una columna para cada año; una columna para cada valor de la variable "year"





# tt_10 ------------------------------------------------------------------------
#- Supongo que te lo imaginas, vamos a volver a pasar a formato LONG, Sí.
# Por favor, pasa los datos de df_wide_2 aformato LONG




# tt_11  [🌶🌶]-----------------------------------------------------------------
#- Se trata de que compares tu pueblo con mi pueblo (Pancrudo)
#- Para ello tienes que usar y modificar el código de la TAREA tt_03 de este script




# tt_12 ------------------------------------------------------------------------
#- borra (usando código) todos los archivos que haya en la carpeta "./datos/pruebas/"





# SOLUCIONES -------------------------------------------------------------------

# ss_01 ------------------------------------------------------------------------
my_url <- "https://github.com/perezp44/pjpv.datos.01/raw/master/data/pob_muni_1996_2020.rda"
my_destination <- here::here("pruebas", "pob_mun_1996_2020.rda")

download.file(url = my_url,  destfile = my_destination)        #- con R-base
curl::curl_download(url = my_url,  destfile = my_destination)  #- con el pkg curl mejor



# ss_02 ------------------------------------------------------------------------
df <- rio::import(my_destination) #- ya hemos descargado el fichero, lo importamos del PC, no del url




# ss_04 ------------------------------------------------------------------------
df_wide <- df_long %>%
  pivot_wider(values_from = pob_total, 
              names_from = ine_muni.n)


# ss_05 ------------------------------------------------------------------------
DT::datatable(df_wide)



# ss_06 ------------------------------------------------------------------------
ruta_wide <- here::here("pruebas", "df_wide.xlsx")
rio::export(df_wide, ruta_wide)



# ss_07 ------------------------------------------------------------------------
ruta_wide <- here::here("pruebas", "df_wide.xlsx")
df_wide <- rio::import(ruta_wide)


# ss_08 ------------------------------------------------------------------------
df_long <- df_wide %>%
  pivot_longer(cols = 2:3) 

df_long <- df_wide %>%
  pivot_longer(cols = 2:3, 
               names_to = "pueblos", 
               values_to = "poblacion")



# ss_09 ------------------------------------------------------------------------
df_wide_2 <- df_long %>%
  pivot_wider(values_from = poblacion, names_from = year)



# ss_10 ------------------------------------------------------------------------
df_long_2 <- df_wide_2 %>%
  pivot_longer(cols = 2:7, names_to = "year")



# ss_11 ------------------------------------------------------------------------
my_destination <- here::here("pruebas", "pob_mun_1996_2020.rda")

df <- rio::import(my_destination)
tu_pueblo <- "Aliaga"   #- has de poner el nombre de tu pueblo!!
library(tidyverse)

df_long_3 <- df %>% filter(ine_muni.n %in% c("Pancrudo", tu_pueblo)) %>%
  filter(year >= 2015) %>%
  select(year, ine_muni.n, pob_total) %>%
  #- pasamos a ancho
  pivot_wider(values_from = pob_total, names_from = ine_muni.n) %>%
  #- pongo la columna de Pancrudo al final
  dplyr::relocate(Pancrudo, .after = last_col()) %>%
  mutate(percent_pancrudo_s_tu_pueblo = .[[3]]/.[[2]]) %>%
  mutate(percent_pancrudo_s_tu_pueblo = round(percent_pancrudo_s_tu_pueblo, digits = 2))


DT::datatable(df_long_3)


# ss_12 ------------------------------------------------------------------------
my_carpeta <- "./pruebas/"
lista_de_archivos <- fs::dir_ls(my_carpeta)
fs::file_delete(lista_de_archivos)

