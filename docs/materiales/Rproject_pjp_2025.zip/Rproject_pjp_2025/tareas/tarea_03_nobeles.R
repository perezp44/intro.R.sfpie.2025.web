#- TAREA 03: 
#- Objetivo: trabajar un poco más manejo de datos con dplyr,
#- enconcreto algunas funciones como ifelse(), case_when(), is.na(), complete.cases(), entre otras
#- y ver q si hay NA's hay que extremar precauciones al seleccionar casos/filas
#- y unir tablas con left_join(), inner_join(), full_join()

#- Datos de premios Nobel del proyecto "Tidy Tuesday"
#- puedes ver los datos aquí: https://github.com/rfordatascience/tidytuesday/tree/master/data/2019/2019-05-14
#- puedes descargarlos de aquí: https://raw.githubusercontent.com/rfordatascience/tidytuesday/master/data/2019/2019-05-14/nobel_winners.csv


#- cargamos paquetes 
library(tidyverse)


# 03_1 -------------------------------------------------------------------------
#- descarga los datos en "./datos/nobel_winners.csv"
el_url <- "https://raw.githubusercontent.com/rfordatascience/tidytuesday/master/data/2019/2019-05-14/nobel_winners.csv"
archivo_de_destino <- here::here("datos", "nobel_winners.csv")
#download.file(el_url, archivo_de_destino)


# 03_2 -------------------------------------------------------------------------
#- importa los datos a R, al Global Env.
#- Podríamos hacerlo con rio::import(), pero lo voy a hacer con readr::read_csv()
#- ventaja: nos mostrará como se lee/interpreta cada columna (si es character etc...)
archivo_de_destino <- here::here("datos", "nobel_winners.csv")
df_original <- readr::read_csv(archivo_de_destino)

zz <- df_original %>% filter(prize_year == 2007) %>% filter(category == "Medicine")
rm(archivo_de_destino, el_url) #- borro lo q no nos hace falta

#- para visualizar mejor los datos voy a dejar solo 7 columnas
df <- df_original %>%
      select(birth_country, laureate_type, prize_year, birth_date, category, gender, full_name)


# 03_3 -------------------------------------------------------------------------
# Se trata de que pienses/expliques que hacen las siguientes lineas de código.

aa <- df %>% filter(birth_country == "Spain")   #- "aa" tiene 7 filas. España solo ha ganado 7 Nobel 6 de ellos en literatura)

aa <- df %>% filter(birth_country != "Spain") #- ¿xq no salen (969-7) filas? salen bastantes menos, concretamente 936

#- La explicación tiene q ver con los NA's. 
#- la razón es que filter() solo se queda con las observaciones que devuelven TRUE en la operación de comparación. 
#- Para empezar a entenderlo ejecuta:
"Spain" == c("Spain", "Francia", NA)

2 == NA  #- no sabemos si 2 es igual a NA (xq el NA podría tomar el valor 2:xq no sabemos su valor y es posible q sea 2)

2 != NA  #- tampoco lo sabemos

4 == "4" #-  4 es "igual" a "4" (xq R convierte el 4 en "4" para poder comparar, coerción implicita)
identical(4, "4")



aa <- df %>% filter(birth_country != "Spain" | is.na(birth_country)) #- ahora sí salen (969-7) filas
# Sí, ahora con las 2 condiciones conseguimos lo que pretendiamos, que era dejar todas las observaciones con Nóbeles que no son españoles (incluidos los q no sabemos de donde son: NA's)


aa <- df %>% filter(!(birth_country %in% c("Spain")) ) #- tb salen (969-7) filas
#- Con esta instrucción también se consigue lo que pretendíamos, que era dejar todas las observaciones con Nobel que no son españoles (incluidos los q no sabemos de donde son: NA's).



aa <- df %>% filter(birth_country %in% c("Spain", "France")) #- selecciona los nobeles ganados por FRA y ESP (60)

aa <- df %>% filter(!(birth_country %in% c("Spain", "France")) ) #- selecciona los nobeles que han sido ganados por otros países que no sean FRA y ESP (no se eliminan los NA's)

#- Tampoco le des muchas-muchas vueltas. La intención del ejercicio es que trabajases un poco con el operador ! , y que vieses que los operadores"==" e  %in% no son exactamente iguales. La conclusión final es que cuando en tu df hay NA's hay que extremar las precauciones al seleccionar los casos/filas



# 03_4 -------------------------------------------------------------------------
#- Muestra los 5 países con más Nobeles
#- Puedes usar n() o count() o ...
aa <- df %>%
      group_by(birth_country) %>%
      summarize(NN = n()) %>%
      slice_max(NN, n = 5) #- USA, UK, GER, FRA, SWE

aa <- df %>%
      count(birth_country, name = "NN")  %>%
      slice_max(NN, n = 5) #- USA, UK, GER, FRA, SWE

# 03_5 -------------------------------------------------------------------------
#- seleccionar los 26 premios Nobel de los que no sabemos el país de nacimiento.
#- Pista: is.na()
aa <- df %>% filter(is.na(birth_country))
aa <- df %>% filter(laureate_type == "Organization") #- resulta que básicamente son los asignados a organizaciones


# 03_6 -------------------------------------------------------------------------
#- Seleccionar los premios Nobel de los que SÍ sabemos el país de nacimiento.
#- Pista: !!!!!!
aa   <- df %>% filter(!is.na(birth_country)) #- devuelve 943 rows (es  la respuesta correcta)

aa_x <- df %>% filter(birth_country != "NA") #- nos devuelve el resultado correcto, PERO podría habernos dado problemas ... si hubiese habido un país que se llamase "NA" (no es el caso, pero podría haberlo sido)

aa_xx <- df %>% filter(birth_country != NA)  #-  devuelve cero rows. Los operadores de comparación que involucran a NAs devuelven NAs

#- CONCLUSION: Para identificar NAs usa la función is.na()

#- Explicación un poco más técnica (es la misma q. la de la pregunta 03_3 ): filter() se quedara con las filas que devuelvan un TRUE al evaluar la condición. La condición es birth_country != "NA". Cuando en una operación de comparación  (como ocurre con !=) está involucrado un NA, la evaluación de la comparación devolverá un NA, no devolverá ni TRUE ni FALSE, devolverá un NA: "los NAs son contagiosos, se propagan".

#- CONCLUSION: Para detectar/identificar NAs usa la función is.na()


# 03_7 -------------------------------------------------------------------------
#- Has de filtrar los casos completos; es decir, dejar solo las filas que no tienen ningún NA.
#- Pista: usa la función tidyr::drop_na(). Igual tenéis que mirar la documentación de la función. Los ejemplos suelen ser bastante ilustrativos

aa_1a <- df %>% tidyr::drop_na()                 #- (938)
aa_1b <- df %>% tidyr::drop_na(birth_country)    #- (943)

aa_2a <- df %>% filter(complete.cases(.))               #- (938)  complete.cases() es de R-base
aa_2b <- df %>% filter(complete.cases(.$birth_country)) #- (943)  complete.cases() es de R-base

aa_3a <- df %>% na.omit       #- (938) na.omit() es de R-base



# 03_8 -------------------------------------------------------------------------
#- Para aquellos premios Nobel que no sabemos donde han nacido, suponemos y ponemos que han nacido en "Marte".
#- Pista: ifelse()

aa <- df %>%
  mutate(birth_country =
           ifelse(is.na(birth_country), "Marte", birth_country))



# 03_9 -------------------------------------------------------------------------
#- Tenéis que crear una nueva variable llamada "my_comentario". Si el Nobel ha nacido en "Spain" ponemos "Olé!!". Si ha nacido en Francia ponemos "Très bien", y si ha nacido en "United States of America" ponemos "Wikidata mola". Para los de los demás países ponemos "NV Nobel ya!!"
#- Pista: la función que tenéis que usar es case_when(). Mira un ejemplo de ayuda y cópialo para empezar
aa <- df %>%
  mutate(my_comentario =  case_when(
                        birth_country == "Spain"   ~ "Olé!!",
                        birth_country == "France"  ~ "Très bien",
                        birth_country == "United States of America" ~ "Wikidata mola",
                        TRUE ~ "NV Nobel ya!!")) %>%
          select(birth_country, my_comentario, everything() )


# 03_10 ------------------------------------------------------------------------
#- Cuantos premios Nobel ha habido cada año:

aa <- df %>% group_by(prize_year) %>% summarise(NN = n())  #- cuantos premios hubo cada año
aa <- df %>% count(prize_year) %>% arrange(desc(n))        #- cuantos premios hubo cada año (ordenados por mayor nº a menor)

# 03_11 ------------------------------------------------------------------------
#- Encontrar el año en el que un sólo país se ha llevado el mayor porcentaje de premios Nobel
#- Pista: hay q agrupar con group_by() 2 veces

aa <- df %>%
  select(prize_year, birth_country) %>%
  group_by(prize_year) %>%
  mutate(n_nobel_ese_anyo = n()) %>%
  group_by(prize_year, birth_country) %>%
  mutate(n_nobel_ese_pais = n()) %>%
  mutate(percent_ese_anyo = n_nobel_ese_pais/n_nobel_ese_anyo)  %>%
  distinct() %>%  #- evitamos duplicados
  arrange(desc(percent_ese_anyo))



#- si quisiera dejar una sola observación por año
bb <- aa %>%
  group_by(prize_year) %>%
  summarise(Max = max(percent_ese_anyo, na.rm = TRUE))

#- lo de arriba esta ok, pero pierdo toda la información (solo dejo 2 columnas)
#- así que lo hago de otra manera
cc <- aa %>%
    group_by(prize_year) %>%
    #- las 2 lineas siguientes se podrían hacer con slice_max()
    arrange(desc(max(percent_ese_anyo, na.rm = TRUE))) %>%
    slice(1) %>%
    ungroup() %>%
    arrange(desc(percent_ese_anyo))

# 03_12 ------------------------------------------------------------------------
#- Encuentra el Nobel más viejo y el más joven
#- Venga, esta vez os ayudo: yo calculo la edad a la que recibieron el premio
str(df) #- la v "birth_date" es de tipo Date (fecha)
typeof(df$birth_date)
class(df$birth_date)
head(df$birth_date)            #- sí, salen como fechas
head(unclass(df$birth_date))   #- !!!!! sí las fechas en realidad-realidad es numerica, concretamente el nº de dias desde 1970-01-01

library(lubridate) #- para trabajar con fechas el paquete lubridate (está en el tidyverse)
aa <- df %>%
  mutate(anyo_nac = lubridate::year(birth_date)) %>%
  mutate(edad = prize_year- anyo_nac) %>%
  select(prize_year, category, full_name, birth_country, birth_date, edad)

bb <- aa %>%
  filter(edad == min(edad, na.rm = TRUE) | edad == max(edad, na.rm = TRUE))



# 03_13 ------------------------------------------------------------------------
#- Calcula la edad media por categoría
#- Warning: cuidado con los NA's al calcular la media

cc <- aa %>% group_by(category) %>%
  summarise(media_edad = mean(edad, na.rm = TRUE)) %>%
  arrange(media_edad)

# 03_14 ------------------------------------------------------------------------
#- calcula la categoría en la que han ganado más porcentaje de mujeres.

aa <- df %>% group_by(category, gender) %>% summarise(NN = n())

aa <- df %>% group_by(category, gender) %>% count(name = "NN", sort = TRUE)

aa <- df %>% count(category, gender, name = "NN", sort = TRUE)


bb <- aa %>% pivot_wider(names_from = gender, values_from = NN)

cc <- bb %>% mutate(percent_F = Female/ (Male + Female)) %>%
  arrange(desc(percent_F))

#- podría estar todo junto y sobra el primer group_by() xq usamos count()

aa <- df %>%
  count(category, gender, name = "NN", sort = TRUE) %>%
  pivot_wider(names_from = gender, values_from = NN) %>%
  mutate(percent_F = Female/ (Male + Female)) %>%
  arrange(desc(percent_F))

#-La verdad es que para hacer tablas básicas no hace falta calentarse la cabeza. Podemos usar el pkg janitor. Lo veremos cuando hagamos EDA. Ejecuta las siguientes instrucciones y verás que fácil salen las tablas
#- Para otras cosas sí q es muy-muy necesario saber manejar datos con tidyverse
library(janitor)

df %>% tabyl(category)
df %>% tabyl(category, gender)
df %>% tabyl(category, gender) %>% adorn_percentages("row")
df %>% tabyl(category, gender) %>% adorn_percentages("row") %>% adorn_pct_formatting()

# 03_15 ------------------------------------------------------------------------
#- Vamos a fusionar dos tablas, dos df's. Por favor fusiona df con gapminder.
#- Os ayudo: pero antes limpiamos el Global Env.
objetos_no_borrar <- c("df")
rm(list = ls()[!ls() %in% objetos_no_borrar])

#- cargamos gapminder en memoria.
gapminder <- gapminder::gapminder

#- simplificamos gapminder: dejamos solo 3 columnas de gapminder y solo el año 2007
gapminder_x <- gapminder %>% select(1, 3, 4) %>% filter(year == 2007)

#- simplifico df: dejo solo el año 2007 y quitamos alguna columna para que todo se vea mejor
df_x <- df %>% 
  filter(prize_year == "2007") %>% 
  select(- c(laureate_type, birth_date)) %>% 
  tidyr::drop_na() %>% 
  distinct()  #- sí, hay duplicados


zz <- df_original %>% filter(prize_year == 2007) %>% filter(category == "Medicine")


#- Tu TAREA: ---
#- vamos a fusionar df y gapminder la variable para poder fusionar es el nombre del país.
#- En df el nombre del país está en la columna "birth_country" y en gapminder el país está en la v. "country"
#- se pueden hacer distintos tipos de fusiones. veamos 3: left, inner y full
#- Explica con palabras que hacen las siguientes 3 expresiones

df_left_join <- left_join(df_x, gapminder_x, by = c("birth_country" = "country"))

df_inner_join <- inner_join(df_x, gapminder_x, by = c("birth_country" = "country"))

df_full_join <- full_join(df_x, gapminder_x, by = c("birth_country" = "country"))



#- PERO lo "feten" sería hacerlo con countrycode::countrycode() para tratar de minimizar los pb's con los nombres

df_x <- df_x %>%
  mutate(country_code = countrycode::countrycode(birth_country, origin = "country.name", destination = "iso3c")) 

gapminder_x <- gapminder_x %>%
  mutate(country_code = countrycode::countrycode(country, origin = "country.name", destination = "iso3c"))

df_left_join_ok <- left_join(df_x, gapminder_x, by = c("country_code" = "country_code"), keep = TRUE)




#- borramos --------------------------------------------------------------------
my_carpeta <- "./datos/pruebas/"
lista_de_archivos <- fs::dir_ls(my_carpeta)
fs::file_delete(lista_de_archivos)

my_carpeta <- "./datos/pruebas"   #- con R-base (por si no tenéis instalado el paquete "fs")
lista_de_archivos <- list.files(my_carpeta, full.names = TRUE)
file.remove(lista_de_archivos)

