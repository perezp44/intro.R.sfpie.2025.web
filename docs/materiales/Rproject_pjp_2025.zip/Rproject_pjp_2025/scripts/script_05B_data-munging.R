#- script para seguir las slides_05A_data-munging


#- pp. 10 ----------------------------------------------------------------------
#- trabajaremos con datos del pkg gapminder

gapminder <- gapminder::gapminder


#- pp. 11 ----------------------------------------------------------------------
#- select() se utiliza para seleccionar variables


#- Seleccionar variables por nombre
aa <- gapminder %>% select(year, lifeExp)

#- Eliminar variables por nombre
aa <- gapminder %>% select(-year, -lifeExp)

#- Seleccionar variables por posición
aa <- gapminder %>% select(1:3, 5)

#- Eliminar variables por posición
aa <- gapminder %>% select(-c(1:3, 5))


#- pp. 12 ----------------------------------------------------------------------
#- A veces queremos reordenar las columnas/variables

#- Podemos hacerlo relocate()
aa <- gapminder %>% dplyr::relocate(country, .after = lifeExp)

aa <- gapminder %>% dplyr::relocate(country, .before = lifeExp)


#- pp. 13 ----------------------------------------------------------------------
#- A veces queremos renombrar las columnas


#- Podemos hacerlo rename()
gapminder %>% rename(life_exp = lifeExp)

#- la funció names() de R-base es útil
aa <- gapminder

names(aa)


#- pp. 14 ----------------------------------------------------------------------
#- A veces queremos CREAR nuevas columnas


aa <- gapminder %>% mutate(GDP = pop * gdpPercap)

aa <- gapminder %>% mutate(GDP = pop * gdpPercap, .after = pop)


#- pp. 15 ----------------------------------------------------------------------
#- filter(): permite seleccionar filas



gapminder <- gapminder::gapminder  #- cargamos los datos

#- Observaciones de España (country == "Spain")
aa <- gapminder %>% filter(country == "Spain")

#- filas con valores de "lifeExp" < 29
aa <- gapminder %>% filter(lifeExp < 29)

#- filas con valores de "lifeExp" entre [29, 32]
aa <- gapminder %>% filter(lifeExp >=  29 &  lifeExp <= 32)
aa <- gapminder %>% filter(between(lifeExp, 29, 32))

#- observaciones de países de África con lifeExp > 32
aa <- gapminder %>% filter(lifeExp > 72 &  continent == "Africa")

#- observaciones de países de África o Asia con lifeExp > 32
aa <- gapminder %>% filter(lifeExp > 72 &  continent %in% c("Africa", "Asia") )
aa <- gapminder %>% filter(lifeExp > 72 & (continent == "Africa" | continent == "Asia") )


#- pp. 16 ----------------------------------------------------------------------
#- slice() es una variante de filter() que selecciona filas por posición



#- selecciona las observaciones de la décima a la quinceava
aa <- gapminder %>% slice(c(10:15))

#- selecciona las 4 primeras observaciones, de la 41 a a la 43, y las 4 últimas
aa <- gapminder %>%
  slice( c(1:4, 41:43, (n()-3):n() ) )



#- pp. 17 ----------------------------------------------------------------------
#- slice_max() y slice_min(): seleccionan filas con valor máximo (o mínimo) de una variable


#- selecciona las 3 filas con mayor valor de lifeExp
aa <- gapminder %>% slice_max(lifeExp, n = 3)

#- selecciona las 4 filas con MENOR valor de pop
aa <- gapminder %>% slice_min(pop, n = 4)

#- observaciones en el primer décil en cuanto a esperanza de vida, 10% con menor esperanza de vida
aa <- gapminder %>% slice_min(lifeExp, prop = 0.1)

#- 1% de observaciones con mayor población. Imagino que estarán China e India
aa <- gapminder %>% slice_max(pop, prop = 0.01)


#- pp. 18 ----------------------------------------------------------------------
#- slice_sample(): permite obtener una muestra aleatoria de los datos


#- selecciona (aleatoriamente) 100 filas de los datos
aa <- gapminder %>% slice_sample(n = 100)

#- selecciona (aleatoriamente) un 5% de los datos
aa <- gapminder %>% slice_sample(prop = 0.05)



#- pp. 19 ----------------------------------------------------------------------
#- arrange(): permite reordenar las filas de un df


#- ordena las filas de MENOR a mayor según los valores de la v. lifeExp
aa <- gapminder %>% arrange(lifeExp)

#- ordena las filas de MAYOR a menor según los valores de la v. lifeExp
aa <- gapminder %>% arrange(desc(lifeExp))

#- ordena las filas de MENOR a mayor según los valores de la v. lifeExp.
#- Si hubiesen empates se resuelve con la variable "pop"
aa <- gapminder %>% arrange(lifeExp, pop)



#- pp. 20 ----------------------------------------------------------------------
#- summarize() para “resumir” variables

aa <- gapminder %>% summarise(maximo = max(pop))  #- el valor máximo de la variable "pop"

aa <- gapminder %>% summarise(NN = n())           #- el número de observaciones

aa <- gapminder %>% summarise(media = mean(lifeExp))  #- la media de la variable "lifeExp"

aa <- gapminder %>% summarise(desviacion_tipica = sd(lifeExp))  #- os lo explicarán en Estadística



#- pp. 21 ----------------------------------------------------------------------

#- summarize(): “resumimos” dos variables
#- retornará 2 valores: las medias de "lifeExp" y "gdpPercap"
aa <- gapminder %>% summarise(mean(lifeExp), mean(gdpPercap))

#- summarize(): hacemos 2 resúmenes de una variable
#- retornará 2 valores: la media y máximo de la v. "lifeExp"
aa <- gapminder %>% summarise(mean(lifeExp), max(lifeExp))



#- pp. 22 ----------------------------------------------------------------------
#- group_by(): con está función ya se puede ver la potencia de dplyr

# calculamos el nº de observaciones en el df
aa <- gapminder %>% summarise(NN = n())
gt::gt(aa)


# ahora queremos calcular el nº de observaciones de cada continente
# cogemos df y lo (des)agrupamos por grupos definidos por la variable "continent"
# o sea, habrá 5 grupos (5 continentes)
# después con summarise() calcularemos el nº de observaciones en cada grupo;
# es decir, nos retornará un df con una fila por cada continente
# con el nº de observaciones de cada continente

bb <- gapminder %>% group_by(continent) %>% summarise(NN = n())

gt::gt(bb)




#- EXTENSIONES -----------------------------------------------------------------


#- pp. 24 ----------------------------------------------------------------------

#- Ejemplo de uso: select() junto a la función where() [🌶🌶🌶🌶]

aa <- gapminder %>% select(is.numeric)        #- funciona, pero ...

aa <- gapminder %>% select(where(is.numeric)) #- es "preferible" esta segunda expresión


#- Si quisieramos seleccionar las variables que NO son numéricas haríamos:
aa <- gapminder %>% select(!where(is.numeric))



#- pp. 25 ----------------------------------------------------------------------
#- más ejemplos de across() y where()

#- Imagina que queremos calcular la media de todas las variables de gapminder.
#- media de todas (everything()) las variables.
#- Devuelve 2 warnings porque las 2 primeras son textuales. No se puede calcular la media de continent y country
gapminder %>% summarise(across(everything(), mean) )


gapminder %>% summarise(across(3:6, mean) )


#- pp. 26 ----------------------------------------------------------------------
#- across() y where() con summarise()       😱

#- Si quisiéramos calcular la media de las variables numéricas
gapminder %>% summarise(across(where(is.numeric), mean))


#- con los nombres de los argumentos (más largo pero conviene verlo de vez en cuando)
gapminder %>% summarise(across(.cols = where(is.numeric), .fns = mean))




#- pp. 27 ----------------------------------------------------------------------
#- summarise() con across() y varias funciones         😱😱😱😱


gapminder %>% summarise(across(3:6, list(media = mean, desv = sd)))


#- lo mismo, pero explicitando los nombres de los argumentos [🌶]
gapminder %>% summarise(across(.cols = 3:6, .fns = list(media = mean, desv = sd) ))


#- lo mismo otra vez, pero eligiendo el nombre de las variables que se van a crear con .names [🌶] [🌶]
gapminder %>% summarise(across(3:6, list(media = mean, desv = sd), .names = "{fn}_{col}"))





#- pp. 28 ----------------------------------------------------------------------
#- Más ejemplos para afianzar el uso de across()

#- Creamos un nuevo df: “gapminder_gr” o “gapminder agrupado”
gapminder_gr <- gapminder %>% filter(year %in% c(1952, 2007)) %>%
  group_by(continent, year)


#- si queremos calcular la media de varias variables tenemos que usar across()
gapminder_gr %>% summarise(across(c(lifeExp, gdpPercap), mean))

#- si queremos calcular la media de todas las variables numéricas tenemos que usar across() y where()
gapminder_gr %>% summarise(across(where(is.numeric), mean))

#- si queremos calcular la media y la mediana, hay que usar list()
gapminder_gr %>% summarise(across(c(lifeExp, gdpPercap),
                                  list (media = mean, mediana = median) ))

#- si ponemos los nombres de los argumentos quedaría como
gapminder_gr %>% summarise(across(.cols = c(lifeExp, gdpPercap),
                                  .fns = list (media = mean, mediana = median)))

#- además, podemos controlar el nombre de las variables creadas con el argumento .names
gapminder_gr %>% summarise(across(c(lifeExp, gdpPercap),
                                  list (media = mean, mediana = median),
                                  .names = "{fn}_{col}"))








#- CONTAR ----------------------------------------------------------------------

#- pp. 33 ----------------------------------------------------------------------

#- 1. Usando mutate() con n()
#- fíjate q con mutate() se mantienen todas las filas y todas las columnas
aa <- gapminder %>% mutate(NN = n())

nrow(aa)  #- se mantienen las 1704 observaciones

#- 1. mutate() mantiene el nº de filas originales (1704)
bb <- head(aa, n = 3)
gt::gt(bb)

#- 2. Usando summarise() con n()
#- fíjate q  summarise() solo devuelve una fila y una columna
aa <- gapminder %>% summarise(NN = n())

#- 2. summarise() devuelve una fila (por grupo)
gt::gt(aa)


#- 3, usando count()
aa <- gapminder %>% count()

#- 3. count() devuelve una fila (por grupo)
gt::gt(aa)


#- pp. 34 ----------------------------------------------------------------------
#- seguimos contando
#- Pero ahora contamos el nº de observaciones de distintos grupos

# fíjate q  summarise() devuelve una fila por cada grupo
# una fila por cada continente
aa <- gapminder %>%
  group_by(continent) %>% summarise(NN = n())

gt::gt(aa)

aa <- gapminder %>% count(continent)

gt::gt(aa)


#- pp. 35 ----------------------------------------------------------------------
#- aun seguimos contando

# fíjate q hay 60 grupos (5 continentes x 12 periodos)
# por lo que devuelve 60 filas, una por grupo

aa <- gapminder %>%
  group_by(continent, year) %>% summarise(NN = n())


aa <- gapminder %>% count(year, continent)

bb <- head(aa, n = 14)
gt::gt(bb)



#- #- pp. 35 -------------------------------------------------------------------
#- Extensión: n() versus nrow()

#- como agrupamos por año y continente, saldrán 60 grupos (12 x 5)

#- con n()
#- como agrupamos por año y continente, saldrán 60 grupos (12 x 5)
aa <- gapminder %>%
  group_by(continent, year) %>% 
  summarise(NN = n()) %>% 
  ungroup()

aa %>% slice(1, 2, 12, 13) %>% 
  gt::gt() %>% 
  gtExtras::gt_theme_guardian()


#- con nrow()
#- como agrupamos por año y continente, saldrán 60 grupos (12 x 5)

#- con nrow()
bb <- gapminder %>% 
  group_by(continent, year) %>% 
  summarise(NN = nrow(.)) %>% 
  ungroup()


bb %>% slice(1, 2, 12, 13) %>% 
  gt::gt() %>% 
  gtExtras::gt_theme_dark()



#- pp. 38 ----------------------------------------------------------------------
#-  ver/obtener observaciones DISTINTAS con distinct()

# gapminder tiene 1.704 filas: ninguna repetida
aa <- gapminder %>% distinct()

# gapminder no tiene filas repetidas
nrow(aa) == nrow(gapminder)

# en gapminder hay 5 valores distintos para los continentes
aa <- gapminder %>% distinct(continent)

# efectivamente 5 continentes
nrow(aa)


# en gapminder hay 5 valores distintos para los continentes y 12 para los periodos
aa <- gapminder %>% distinct(continent, year)

# efectivamente 60:  5 continentes x 12 periodos
nrow(aa)


#- pp. 39 ----------------------------------------------------------------------
#- CONTAR observaciones DISTINTAS con n_distinct()

# nº de países distintos en cada continente
aa <- gapminder %>%
  group_by(continent) %>%
  summarise(NN = n_distinct(country))

gt::gt(aa)


# nº de países distintos en cada continente
aa <- gapminder %>%
  group_by(year, continent) %>%
  summarise(NN = n_distinct(country)) %>% 
  ungroup()


gt::gt(head(aa, n = 7))



#- pp. 41 ----------------------------------------------------------------------
#- calculando ESTADISTICOS: máximo, mínimo, media, ……


aa <- gapminder %>%
  summarise(maximo = max(lifeExp, na.rm = TRUE),
            minimo = min(lifeExp, na.rm = TRUE),
            media = mean(lifeExp, na.rm = TRUE) )

gt::gt(aa)

#- calcular estadísticos por continente
aa <- gapminder %>% group_by(continent) %>%
  summarise(maximo = max(lifeExp, na.rm = TRUE),
            minimo = min(lifeExp, na.rm = TRUE),
            media = mean(lifeExp, na.rm = TRUE) )

aa %>% gt::gt()


#- pp. 42 ----------------------------------------------------------------------
#- ESTADISTICOS para Europa año a año ...

#- calcular estadísticos por CONTINENTE Y AÑO
aa <- gapminder %>%
  group_by(continent, year) %>%
  summarise(maximo = max(lifeExp, na.rm = TRUE),
            minimo = min(lifeExp, na.rm = TRUE),
            mean = mean(lifeExp, na.rm = TRUE) ) %>%
  ungroup() %>%
  filter(continent == "Europe")



aa %>% gt::gt() %>% gt::fmt_number(3:5, decimals = 2)


#- pp. 43 ----------------------------------------------------------------------
#- en la slide anterior, al calcular la esperanza de vida media por continente,
#- estábamos promediando países con diferente población 🫣

#- Tarea:  hemos de calcular la media, pero ponderada por la población (pop)

#- Solución
aa <- gapminder %>%
  group_by(continent, year) %>%
  summarise(mean = mean(lifeExp, na.rm = TRUE),
            mean_w = weighted.mean(lifeExp, w = pop, na.rm = TRUE)) %>%
  ungroup() %>%
  filter(year == 2007)



#- pp. 45 ----------------------------------------------------------------------
#- empezamos con una pregunta sencilla, pero …



#- à la tidyverse (4 soluciones)
#- I
aa <- gapminder %>% group_by(country) %>%
  summarize(NN = n())

aa <- gapminder %>% count(country)
aa %>% slice(1, 2, 142) %>% gt::gt()

#- II
aa <- gapminder %>%
  summarise(NN_paises = n_distinct(country))
aa %>% gt::gt()


#- III
aa <- distinct(gapminder, country)
aa %>% slice(1, 2, 142) %>% gt::gt()

#- IV
aa <- n_distinct(gapminder$country)

aa <- n_distinct(gapminder %>% select(country))
aa


#- à la R-base
#- Solución “canónica” en R-base (además, se sigue viendo mucho):
length(unique(gapminder$country))


#- lo más equivalente en el tidyverse sería:
gapminder %>% count(country) %>% nrow()




#- pp. 46 ----------------------------------------------------------------------
#- otra pregunta

#- En gapminder ¿Cuantos países distintos hay en cada continente?
#- Después, calcula el porcentaje de países de cada continente sobre el total


#- Solución à la tidyverse
aa <- gapminder %>%
  group_by(continent) %>%
  summarize(NN = n_distinct(country)) %>%
  mutate(NN_total = sum(NN)) %>%
  mutate(porcentaje = (NN / NN_total) * 100)


#- solución à la R-base (seguro q se puede mejora algo ...)
bb <- unique(gapminder[, c("country", "continent")])
cc <- aggregate(country ~ continent, data = bb, FUN = length)

# Renombrar la columna de conteo
colnames(cc)[colnames(cc) == "country"] <- "NN"

# Calcular el número total de países únicos en gapminder
NN_total <- sum(cc$NN)
cc$NN_total <- NN_total

# Calcular el porcentaje de países de cada continente sobre el total
cc$porcentaje <- (cc$NN / cc$NN_total) * 100




#- pp. 47 ----------------------------------------------------------------------
#- ahora … una pregunta de verdad

#- ¿En que continente ha aumentado más la esperanza de vida en el periodo 1952-2007?

#- Intento 0
#- esta parte va a ser común en las 4 soluciones

aa <- gapminder %>%
  filter(year %in% c(1952, 2007)) %>%
  group_by(continent, year) %>%
  summarize(media = mean(lifeExp)) %>% ungroup()

gt::gt(aa)

#- Intento 1
#- se podría hacer de una vez, pero partimos el código en 2 trozos

aa <- gapminder %>% filter(year %in% c(1952, 2007)) %>%
  group_by(continent, year) %>%
  summarize(media = mean(lifeExp)) %>% ungroup()

gt::gt(aa)


bb <- aa %>% group_by(continent) %>%
  summarise(min_l = min(media), max_l = max(media)) %>%
  mutate(dif = max_l-min_l) %>%
  arrange(desc(dif))

gt::gt(bb)



#- Intento 2

#- el primer trozo sigue siendo comuún

aa <- gapminder %>% filter(year %in% c(1952, 2007)) %>%
  group_by(continent, year) %>%
  summarize(media = mean(lifeExp)) %>% ungroup()

#- usamos lag()
bb <- aa %>% group_by(continent) %>%
  arrange(year) %>%
  mutate(variacion = media - lag(media)) %>% ungroup()

gt::gt(bb)

#- para mostrar  los resultados
cc <- bb %>% filter(year == 2007) %>% arrange(desc(variacion))

gt::gt(cc)

#- Intento 3
#- ya sabemos que la primera parte es común

aa <- gapminder %>%
  filter(year %in% c(1952, 2007)) %>%
  group_by(continent, year) %>%
  summarize(media = mean(lifeExp)) %>% ungroup()

gt::gt(aa)


#- pero ahora usamos pivot_wider()
bb <- aa %>% pivot_wider(names_from = year, values_from = media) %>%
  mutate(dif_l = 2007 - 1952) %>%
  arrange(desc(dif_l))

gt::gt(bb)



#- pp. 48 ----------------------------------------------------------------------
#- preguntas de verdad (II)
#- ¿qué hace el código de abajo?

aa <- gapminder %>%
  group_by(continent, year) %>%
  select(continent, year, lifeExp) %>%
  summarise(mean_life = mean(lifeExp)) %>%
  arrange(year) %>%
  mutate(incre_mean_life_0 = mean_life - first(mean_life)) %>%
  mutate(incre_mean_life_t = mean_life - lag(mean_life)) %>%
  arrange(continent) %>%
  ungroup()

#- por ejemplo veamos el resultado para Europe
bb <- aa %>% filter(continent == "Europe")

gt::gt(bb)



#- pp. 49 ----------------------------------------------------------------------
#- preguntas de verdad (III)

#- Tarea I: ¿Cómo ha evolucionado la esperanza de vida en España?

#- variación de lifeExp en Spain año a año (bueno lustro a lustro)

aa <- gapminder %>% group_by(country) %>%
  select(country, year, lifeExp) %>%
  mutate(life_gain = lifeExp - lag(lifeExp)) %>%
  filter(country == "Spain" ) %>%
  ungroup()

#- Tarea II: ¿Y la variación acumulada? Fácil!!

#- Solución IIa
aa <- gapminder %>% group_by(country) %>%
  select(country, year, lifeExp) %>%
  mutate(life_gain = lifeExp - lag(lifeExp)) %>%
  #- Al final para hacerlo (como había pensado) me han hecho falta 2 lineas,
  #- xq la primera observación de "life_gain" es un NA
  #- y eso hacía que la función cumsum() no funcionase.
  mutate(life_gain_2 =
           ifelse(is.na(life_gain), 0, life_gain)) %>%
  mutate(life_gain_acu = cumsum(life_gain_2)) %>%
  filter(country == "Spain") %>%
  ungroup()

gt::gt(aa)

#- Solución IIb
#- ganancia acumulada (otra forma de hacer lo mismo)

aa <- gapminder %>% group_by(country) %>%
  select(country, year, lifeExp) %>%
  mutate(life_gain_acu = lifeExp - lifeExp[1])  %>%
  filter(country == "Spain") %>%
  ungroup()

gt::gt(aa)




#- pp. 50 ----------------------------------------------------------------------
#- a ver si entendéis estos ejemplos

#- ejemplo 1
aa <- gapminder %>%
  filter(continent == "Asia") %>%
  select(year, country, lifeExp) %>%
  group_by(year) %>%
  slice_max(n = 3, lifeExp) %>%
  arrange(year) %>%
  ungroup()

aa %>% head(10) %>% gt::gt()


#- ejemplo 2
aa <- gapminder %>%
  group_by(continent, year)  %>%
  mutate(media_life = mean(lifeExp)) %>%
  mutate(media_gdp = mean(gdpPercap)) %>%
  mutate(GOOD_or_BAD = case_when(
    lifeExp > mean(lifeExp) & gdpPercap > mean(gdpPercap)  ~ "good",
    lifeExp < mean(lifeExp) & gdpPercap < mean(gdpPercap)  ~ "bad" ,
    lifeExp < mean(lifeExp) | gdpPercap < mean(gdpPercap)  ~ "medium",
    .default = "otros casos"
  )) %>%
  filter(country == "Spain") %>%
  ungroup()


aa %>%
  select(year, country, continent, lifeExp, gdpPercap,
         media_life, media_gdp, GOOD_or_BAD) %>%
  gt::gt()






#- pp. 52 ----------------------------------------------------------------------
#- calculando CRECIMIENTOS
#- calcular el crecimiento de la esperanza de vida, de un periodo a otro, en España

aa <- gapminder %>%
  select(country, year, lifeExp) %>%
  group_by(country) %>%
  arrange(year) %>%
  mutate(crecimiento =  lifeExp - lag(lifeExp)) %>%
  mutate(crecimiento2 = lifeExp - lag(lifeExp, default = first(lifeExp))) %>%
  ungroup() %>%
  filter(country == "Spain")

gt::gt(aa) %>%
  gt::fmt_number(3:5, decimals = 2)




#- pp. 53 ----------------------------------------------------------------------
#- calculando CRECIMIENTOS ACUMULADOS

aa <- gapminder %>%
  select(country, year, lifeExp) %>%
  group_by(country) %>%
  arrange(year) %>%
  mutate(crec_1 = lifeExp - lag(lifeExp)) %>%
  mutate(crec_2 = lifeExp - lag(lifeExp, default = first(lifeExp))) %>%
  mutate(crec_acu_1 = cumsum(crec_1)) %>%
  mutate(crec_acu_2 = cumsum(crec_2)) %>%
  mutate(crec_acu_3 = lifeExp - first(lifeExp)) %>%
  ungroup() %>%
  filter(country == "Spain")

gt::gt(aa) %>%
  gt::fmt_number(3:8, decimals = 2)




#- pp. 55 ----------------------------------------------------------------------
#- calculando PORCENTAJES (con R à la tidyverse)


#- Calcular % de población de cada continente
aa <- gapminder %>%
  group_by(continent, year) %>%
  summarise(pob_continent = sum(pop, na.rm = TRUE)) %>% ungroup() %>%
  group_by(year) %>%
  mutate(pob_mundo = sum(pob_continent),
         pob_percent = pob_continent/pob_mundo * 100) %>%
  ungroup()



bb <- aa %>% filter(year %in% c(1952, 2007))



gt::gt(head(bb, n = 15)) %>%
  gt::fmt_number(pob_percent, decimals = 2)





#- pp. 56 ----------------------------------------------------------------------
#- Extensión: tabla con la importancia (en términos de población) de cada continente en el tiempo

#- Ahora quiero hacer la tabla presentable: he de pasarla a formato ancho

bb <- aa %>%
  select(continent, year, pob_mundo, pob_percent) %>%
  tidyr::pivot_wider(names_from = continent,
                     values_from = pob_percent)

gt::gt(bb) %>%
  gt::fmt_number(2, sep_mark = ".", decimals = 0) %>%
  gt::fmt_number(3:7, decimals = 1)





#- pp. 58 ----------------------------------------------------------------------
#- calculando RANKINGs


#- Calcular el ranking de España en cuanto a Esperanza de vida

aa <- gapminder %>%
  select(country, year, lifeExp) %>%
  group_by(year) %>%
  mutate(rank_1 = row_number(desc(lifeExp))) %>%
  mutate(rank_2 = min_rank(desc(lifeExp)) ) %>%
  #- también puedo calcular el ranking a mano
  arrange(desc(lifeExp)) %>%
  mutate(rank_mio = 1:n())  %>%
  ungroup()


aa %>%
  filter(country == "Spain") %>%
  gt::gt() %>%
  gt::fmt_number(3:5, decimals = 0)





#- pp. 60 ----------------------------------------------------------------------
#- ifelse(): ejecuta “algo” de manera condicional


aa <- gapminder %>%
  select(-pop) %>%
  mutate(X1 = ifelse(lifeExp > 70, "longevo", "no longevo")) %>%
  mutate(X2 = ifelse(gdpPercap > 10000, "rico", "pobre")) %>%
  mutate(X3 = ifelse(lifeExp > 70 & gdpPercap > 10000,
                     "longevo y rico",
                     "no longevo y/o pobre")) %>%
  mutate(X4 = ifelse(continent == "Europe", "europeo", "no europeo"))


#- el resultado es:
aa %>% filter(country %in% c("Spain", "Angola")) %>%
  filter(year %in% c(1952, 2007)) %>%
  gt::gt() %>%
  gt::opt_stylize(style = 3) %>%
  gt::cols_align(align = "center")



#- pp. 61 ----------------------------------------------------------------------
#- case_when(): es una generalización de ifelse()

aa <- gapminder %>%
  group_by(continent, year)  %>%
  mutate(media_lifeExp = mean(lifeExp)) %>%
  mutate(media_gdpPercap = mean(gdpPercap)) %>%
  mutate(GOOD_or_BAD = case_when(
    lifeExp > mean(lifeExp) & gdpPercap > mean(gdpPercap)  ~ "good",
    lifeExp < mean(lifeExp) & gdpPercap < mean(gdpPercap)  ~ "bad" ,
    lifeExp < mean(lifeExp) | gdpPercap < mean(gdpPercap)  ~ "medium",
    .default = "otros casos"  ) )


#- el resultado es:
aa %>% ungroup() %>% filter(country == "Spain") %>% select(-pop) %>%
  gt::gt() %>%
  gt::fmt_number(4:7, sep_mark = ".",   dec_mark = ",", decimals = 2) %>%
  gt::opt_stylize(style = 2) %>%
  gt::cols_align(align = "center")




#- pp. 63 ----------------------------------------------------------------------
#- dos casos ideales (sencillos de unir): bind_cols() y bind_rows()

#- A) Si los 2 dfs tienen exactamente las mismas filas o unidades de análisis (y además en el mismo orden)

df_1 <- iris[ , 1:2]  ; df_2 <- iris[ , 3:5]

df_1 <- iris %>% select(1:2)  ; df_2 <- iris %>% select(3:5)

df_3 <- bind_cols(df_1, df_2)

identical(iris, df_3)


#- B) Si los 2 dfs tienen exactamente las mismas columnas (y además en el mismo orden)

df_1 <- iris[1:75, ]  ; df_2 <- iris[76:150, ]

df_1 <- iris %>% slice(1:75)  ; df_2 <- iris %>% slice(76:150)

df_3 <- bind_rows(df_1, df_2)

identical(iris, df_3)




#- pp. 65 ----------------------------------------------------------------------
#- mutating joins: un ejemplo
#- En el ejemplo usaremos estos 2 df’s:



df1 <- tibble(id = 1:3, x = paste0("x", 1:3))
df2 <- tibble(id = 1:4, y = paste0("y", 1:4)) %>% slice(-3)

df1
df2

#- pp. 66 ----------------------------------------------------------------------

df_inner <- inner_join(df1, df2)    #- inner_join() only includes observations that match in df1 and df2


df_full_join <- full_join(df1, df2)     #- full_join() includes all observations from df1 and df2


df_left_join <- left_join(df1, df2)   #- left_join()  includes all observations in df1





