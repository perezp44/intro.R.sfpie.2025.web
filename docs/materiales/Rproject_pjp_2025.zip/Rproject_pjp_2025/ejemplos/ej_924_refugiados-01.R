# Cargar librerías necesarias
library(refugees)
library(tidyverse)

flows <- refugees::flows


# Filtrar variables relevantes y limpiar datos
flows_clean <- flows %>%
  select(year, coo_name, coa_name, refugees) %>%
  filter(!is.na(refugees), 
         refugees > 0,
         !is.na(coo_name),
         !is.na(coa_name)) %>%
  rename(
    origen = coo_name,
    destino = coa_name,
    refugiados = refugees
  )

#- evolución por país de origen (año a año)
refugiados_por_origen <- flows_clean %>%
  group_by(year, origen) %>%
  summarise(total_refugiados = sum(refugiados, na.rm = TRUE), .groups = 'drop') %>%
  arrange(year, desc(total_refugiados))

#- evolución por país de destino  
refugiados_por_destino <- flows_clean %>%
  group_by(year, destino) %>%
  summarise(total_refugiados = sum(refugiados, na.rm = TRUE), .groups = 'drop') %>%
  arrange(year, desc(total_refugiados))


#- función para crear gráficos de evolución x país -----------------------------
p_evolucion_pais <- function(data, pais, tipo = "origen") {
  
  # Filtrar datos según el tipo (origen o destino)
  if(tipo == "origen") {
    datos_pais <- data %>%
      filter(origen == pais) %>%
      group_by(year) %>%
      summarise(total = sum(refugiados, na.rm = TRUE), .groups = 'drop')
    titulo <- paste("Evolución de Refugiados desde", pais)
    subtitulo <- "Total de refugiados por año de origen"
  } else {
    datos_pais <- data %>%
      filter(destino == pais) %>%
      group_by(year) %>%
      summarise(total = sum(refugiados, na.rm = TRUE), .groups = 'drop')
    titulo <- paste("Evolución de Refugiados hacia", pais)
    subtitulo <- "Total de refugiados por año de destino"
  }
  
  # Crear gráfico
  ggplot(datos_pais, aes(x = year, y = total)) +
    geom_line(color = "steelblue", size = 1.2) +
    geom_point(color = "darkblue", size = 2) +
    scale_y_continuous(labels = scales::comma_format()) +
    labs(
      title = titulo,
      subtitle = subtitulo,
      x = "Año",
      y = "Número de Refugiados",
      caption = "Fuente: UNHCR via refugees package"
    ) +
    theme_minimal() +
    theme(
      plot.title = element_text(size = 14, face = "bold"),
      plot.subtitle = element_text(size = 12),
      axis.text.x = element_text(angle = 45, hjust = 1)
    )
}

# Ejemplos de uso del gráfico (cambiar el país según necesidad)
# Para país de origen:

my_pais <- "Syrian Arab Rep."
my_pais <- "Ukraine"
my_pais <- "Afghanistan"
my_pais <- "State of Palestine"


my_p <- p_evolucion_pais(flows_clean, my_pais, "origen")
my_p



# Para país de destino:
my_p_destino <- p_evolucion_pais(flows_clean, "Germany", "destino")
my_p_destino


# Resumen estadístico general
resumen_general <- flows_clean %>%
  group_by(year) %>%
  summarise(
    total_refugiados = sum(refugiados, na.rm = TRUE),
    paises_origen = n_distinct(origen),
    paises_destino = n_distinct(destino),
    flujos_activos = n(),
    .groups = 'drop'
  )

# Gráfico de tendencia general
p_tendencia_general <- ggplot(resumen_general, aes(x = year, y = total_refugiados)) +
  geom_line(color = "red", size = 1.2) +
  geom_point(color = "darkred", size = 2) +
  scale_y_continuous(labels = scales::comma_format()) +
  labs(
    title = "Evolución Global de Refugiados",
    subtitle = "Total mundial por año",
    x = "Año",
    y = "Número Total de Refugiados",
    caption = "Fuente: UNHCR via refugees package"
  ) +
  theme_minimal() +
  theme(
    plot.title = element_text(size = 14, face = "bold"),
    plot.subtitle = element_text(size = 12),
    axis.text.x = element_text(angle = 45, hjust = 1)
  )

p_tendencia_general

