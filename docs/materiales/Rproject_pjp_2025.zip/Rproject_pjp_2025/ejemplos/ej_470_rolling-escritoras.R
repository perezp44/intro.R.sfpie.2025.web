#- premios literarios en Wikidata
library(tidyverse)

df <- rio::import("./datos/premios_literarios.csv")


mys_paises <- c("Spain", "Italy", "France", "United Kingdom", "Germany", "United States", "Norway")



#- ROLLING - %'s ---------------------------------------------------------------
#- slider: lo mismo pero usando el pkg slider 

qq_lags = 5  #- elegir cuantos retardos y cuantos leads
qq_leads = 5

qq_smpl_inicial = 1950  #- restrinjo muestra
qq_smpl_final = 2024



#- Tabla 7b: Rolling-PAÍSES ----------------------------------------------------

zz <- df %>% 
  distinct(escritor, premio_recibido, genderLabel.a, year_premio, pais_del_premio) %>% 
  tidyr::drop_na(genderLabel.a)  %>%   #- quito NA's en genero (en realidad todos tienen)
  tidyr::drop_na(year_premio)    %>%   #- quito NA's en genero (en realidad no hace falta xq agrupo x year)
  filter(between(year_premio, qq_smpl_inicial, qq_smpl_final)) %>%  #- [restrinjo muestra] 
  group_by(pais_del_premio, year_premio) %>% 
  arrange(year_premio) %>% 
  mutate (nn_total_ese_anyo = n()) %>% 
  group_by(pais_del_premio, year_premio, genderLabel.a) %>% 
  mutate(nn_mujeres_ese_anyo = n()) %>%    #- mal nombre, pero ...
  ungroup() %>% 
  distinct(pais_del_premio, year_premio, genderLabel.a, nn_total_ese_anyo, nn_mujeres_ese_anyo) %>% 
  tidyr::complete(pais_del_premio, genderLabel.a, year_premio, fill = list(nn_mujeres_ese_anyo = 0)) %>% 
  #------ nou
  group_by(pais_del_premio, year_premio) %>% 
  mutate(nn_total_ese_anyo = ifelse(is.na(nn_total_ese_anyo), 0, nn_total_ese_anyo)) %>%  #- si fuese NA a zero
  mutate(nn_total_ese_anyo = max(nn_total_ese_anyo, na.rm = TRUE)) %>% #- si hay un NA, pasa al maximo, el otro
  #mutate(nn_total_ese_anyo = ifelse(is.na(nn_total_ese_anyo), 0, nn_total_ese_anyo)) %>%  #- si fuesen los 2 NA's
  #------ nou
  group_by(pais_del_premio, year_premio) %>% 
  arrange(genderLabel.a) %>% 
  mutate(nn_total_ese_anyo = last(nn_total_ese_anyo)) %>% 
  filter(genderLabel.a == "femenino") %>% select(-genderLabel.a) %>% 
  group_by(pais_del_premio) %>% 
  mutate(percent_muj_ese_anyo = nn_mujeres_ese_anyo/nn_total_ese_anyo) %>% 
  mutate(nn_total_slide = slider::slide_dbl(nn_total_ese_anyo, sum, .before = qq_lags, .after = qq_leads, .complete = TRUE)) %>% 
  mutate(nn_mujeres_slide = slider::slide_dbl(nn_mujeres_ese_anyo, sum, .before = qq_lags, .after = qq_leads, .complete = TRUE)) %>% 
  mutate(percent_muj_slide = nn_mujeres_slide/nn_total_slide) 



#- selecciono países o sample
zz_espana <- zz %>% filter(pais_del_premio == "Spain")
zz_tt  <- zz %>% filter(year_premio %in% c(1960, 2013))
zz_italia <- zz %>% filter(pais_del_premio == "Italy")


#- gráfico
paises_grafico <- c("Spain", "Italy", "France", "United Kingdom", "Germany", "United States", "Norway")

p <- ggplot(zz %>% filter(pais_del_premio %in% paises_grafico), 
            aes(x = year_premio, y = percent_muj_slide, color = pais_del_premio)) +
  geom_point() +
  geom_line()

p



