# Análisis de Llegadas de Refugiados a España
# UNHCR (The UN Refugee Agency): https://www.unhcr.org/refugee-statistics/insights/explainers/refugees-r-package.html
# UNHCR's refugees R package covers forcibly displaced populations, 
# including refugees, asylum-seekers and internally displaced people, stateless people, and others over a span of more than 70 years. 
# Dataset usado: flows (del paquete refugees): contiene datos de llegadas de refugiados a diferentes países, incluyendo España.

# Cargar paquetes necesarias
library(refugees)
library(tidyverse)


# Cargar el dataset flows
flows <- refugees::flows 

#- quito 2 variables
flows <- flows %>% select(-coo, -coa)

#- nos centramos en las llegadas (coa_name) a Spain
df <- flows %>% filter(coa_name == "Spain")



#- 1) refugiados a España? -----------------------------------------------------
# Resumen anual para Spain (cuanta gente llega a España como refugiado, ....)
spain_arrivals <- df %>%
  group_by(year) %>%
  summarise(
    total_refugees = sum(refugees, na.rm = TRUE),
    total_asylum = sum(asylum_seekers, na.rm = TRUE),
    total_refugee_like = sum(refugee_like, na.rm = TRUE),
    total_oip = sum(oip, na.rm = TRUE)  )

#- across() --------------------------------------------------------------------
#- el pb del código de arriba es que "repetimos código"
#- podemos usar across() para evitar repetir el código

spain_arrivals <- df %>%
  group_by(year) %>%
  summarise(across(c(refugees, asylum_seekers, refugee_like, oip),
                   sum, na.rm = TRUE) )

#- 😱😱😱 funciona, PERO ....
#- nos devuelve un warning: The `...` argument of `across()` is deprecated as of dplyr 1.1.0.
#- y nos dice q la solución es: Supply arguments directly to `.fns` through an anonymous function instead
#- y nos pone un ejemplo:
#- antes se hacia:   across(a:b, mean, na.rm = TRUE)
#- ahora se hace:    across(a:b, \(x) mean(x, na.rm = TRUE))



#- cositas de FUNCIONES --------------------------------------------------------

##- f. anonima (shorthand notation) -------------------------------------------
#- es decir estamos usando una función anónima (lambda function) con shorthand notation
spain_arrivals <- df %>%
  group_by(year) %>%
  summarise(across(c(refugees, asylum_seekers, refugee_like, oip),
                   \(x) sum(x, na.rm = TRUE)  ) )

##- f. anonima ("notacicion completa) -------------------------------------------
#- o con f. anónimas con la notación completa (sin shorthand notation)
spain_arrivals <- flows %>%
  filter(coa_name == "Spain") %>% 
  group_by(year) %>%
  summarise(across(c(refugees, asylum_seekers, refugee_like, oip),
                   function(x) sum(x, na.rm = TRUE)  )  )


#- podemos poner llaves en el código de la función anónima
spain_arrivals <- flows %>%
  filter(coa_name == "Spain") %>% 
  group_by(year) %>%
  summarise(across(c(refugees, asylum_seekers, refugee_like, oip),
                   function(x){ sum(x, na.rm = TRUE) }  )  )

##- formula syntax --------------------------------------------------------------
#- o con notación de formulas
spain_arrivals <- df %>%
  group_by(year) %>%
  summarise(across(c(refugees, asylum_seekers, refugee_like, oip),  
                   ~ sum(.x, na.rm = TRUE)  )  )


##- función con nombre (named function) ----------------------------------------
#- tb podemos hacerlo con una función "completa", una named function
my_fun <- function(x){
  sum(x, na.rm = TRUE) 
}

spain_arrivals <- df %>%
  group_by(year) %>%
  summarise(across(c(refugees, asylum_seekers, refugee_like, oip),
                   my_fun)  )


##- varias funciones -----------------------------------------------------------
#- calculamos dos cosas y usamos shorthand notation pero con más argumentos para tener "nombres dinámicos"
spain_arrivals <- df %>%
  group_by(year) %>%
  summarise(
    across(c(refugees, asylum_seekers), 
           list(suma = \(x) sum(x, na.rm = TRUE), 
                maximo = \(x) max(x, na.rm = TRUE)), 
           .names = "{.fn}_{.col}"), 
    .groups = "drop")

#- hay 41 warning x max()


#- 2) De q países vienen a España?? --------------------------------------------

# Top países de origen de refugiados en España
spain_top_countries <- df %>% 
  filter(!is.na(refugees)) %>% 
  group_by(coo_name) %>%
  summarise(
    total_refugees = sum(refugees, na.rm = TRUE),
    years_active = n_distinct(year),
    avg_per_year = mean(refugees, na.rm = TRUE),
    max_year = max(refugees, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  arrange(desc(total_refugees)) 


#- imagina que queremos repetir el código de arriba, pero con otra variable ¿q hacemos?
#- si podemos copiar el código, PERO .... 

#- quiero hacerlo general para todas las variables, entonces vamos a usar TIDYEVAL

##- TIDYEVAL -------------------------------------------------------------------

#- vamos a simplificar nuestros cálculos x q quiero ver algo de TIDYEVAL. Por ejemplo:
zz <- df %>% 
  group_by(coo_name) %>%
  summarise(total_refugees = sum(refugees, na.rm = TRUE)) 
  

#- estoy calculando los refugiados totales x país
#- para ello uso la variable "refugees" que está dentro del dataset df


my_vv <- "refugees" #- my_vv es un objeto que contiene la cadena de texto "refugees"

#- este código todos sabemos q quiere hacer ... PERO no funciona xq?
zz <- df %>% 
  group_by(coo_name) %>%
  summarise(total_refugees = my_vv, na.rm = TRUE))   


#- no funciona xq  dentro de df no existe la vv. my_vv
#- my_vv existe, PERO en el Clobal, no dentro de df


#- con summarise()
#- para poder usar my_vv dentro de df, tenemos que usar "tidyeval"
#- no podemos usar my_vv xq es una cadena de texto, hay que ...
#- convertirla en un símbolo (con sym()) 
#- para después decirle (con el operador !!) q lo evalúe


# Opción 1: Usando sym() para convertir string a símbolo
spain_top_origin_countries <- df %>% 
  group_by(coo_name) %>%
  summarise(total_refugees = sum(!!sym(my_vv), na.rm = TRUE)) 


#- Opción 2: Define directamente my_vv como símbolo desde el principio
my_vv <- sym("refugees")

spain_top_origin_countries <- df %>% 
  group_by(coo_name) %>%
  summarise(total_refugees = sum(!!my_vv, na.rm = TRUE))


#- Opción 3: Usa .data[[]] que es más directo para referencias de columnas dinámicas
#- La Opción 3 con .data[[]] es generalmente la más recomendada porque es más clara y menos propensa a errores. 
#- Es la forma moderna y preferida de hacer programación con dplyr cuando tienes nombres de columnas como strings.
#- En jerga estamos usando .data pronoun 

my_vv <- "refugees"

spain_top_origin <- df %>% 
  group_by(coo_name) %>%
  summarise(total_refugees = sum(.data[[my_vv]], na.rm = TRUE)) 



#- ok, ahora quiero algo más:
#- quiero que el nombre de las variables total_refugess que estamos creando 
#- cambie en funcion del nombre que usemos en my_vv; 
#- es decir que si my_vv <- "petardo" , entonces la variable que creamos sea: total_petardo
#- tendremos que 
#- 1) seguir usando !! para evaluar expresiones (o símbolos)
#- 2) usar := en lugar de =  para poder asignar nombres dinámicos 



my_vv <- "refugees"
my_vv <- "asylum_seekers"  

# Opción 1: Usando sym() y := para nombres dinámicos
spain_top_origin <- df %>% 
  group_by(coo_name) %>%
  summarise( !!paste0("total_", my_vv) := sum(!!sym(my_vv), na.rm = TRUE))


# Opción 2: Usando .data pronoun con nombres dinámicos
my_vv <- "refugees"

spain_top_origin <- df %>% 
  group_by(coo_name) %>%
  summarise( !!paste0("total_", my_vv) := sum(.data[[my_vv]], na.rm = TRUE)) 











#- más de FUNCIONES ------------------------------------------------------------

#- con las funciones se facilita el poder expresar cálculos más complejos. Por ejemplo:

#- ahora para la variable asylum_seekers
spain_standardized <- df %>%
  group_by(coo_name) %>%
  filter(n() >= 5) %>%  # Solo países con al menos 5 años de datos
  mutate(
    # Z-score estandarización
    asylum_seekers_z = (\(x) (x - mean(x, na.rm = TRUE)) / sd(x, na.rm = TRUE))(asylum_seekers),
    # Normalización min-max
    asylum_seekers_normalized = (\(x) (x - min(x, na.rm = TRUE)) / (max(x, na.rm = TRUE) - min(x, na.rm = TRUE)))(asylum_seekers),
    # Índice base 100 (primer año = 100)
    asylum_seekers_index = (\(x) (x / x[1]) * 100)(asylum_seekers)
  ) %>%
  ungroup() %>% 
  filter(coo_name == "State of Palestine") %>% 
  select(year, coo_name, asylum_seekers, asylum_seekers_z, asylum_seekers_normalized, asylum_seekers_index) %>% 
  filter(!is.na(asylum_seekers_z) & !is.na(asylum_seekers_normalized) & !is.na(asylum_seekers_index))




#- quiero calcular la evolución de los refugiados totales de Palestina en el tiempo
zz_palestina <- flows %>% 
  filter(coo_name == "State of Palestine") %>% 
  group_by(year) %>%
  summarise(total_refugees = sum(refugees, na.rm = TRUE)) %>%
  arrange(year) 
  
zz_palestina <- flows %>% 
  filter(coo_name == "State of Palestine") %>% 
  group_by(year) %>%
  summarise(total_asy_seek = sum(asylum_seekers, na.rm = TRUE)) %>%
  arrange(year) 





#- 3) Refugiados totales -------------------------------------------------------
# Calculamos suma de refugiados por país de origen (coo_name) y año
refugees_by_origin_year <- flows %>%
  filter(!is.na(refugees)) %>%  # Eliminar valores NA
  group_by(coo_name, year) %>%
  summarise(
    total_refugees = sum(refugees, na.rm = TRUE),
    destinations = n_distinct(coa_name),  # Número de países de destino
    .groups = "drop"
  ) %>%
  arrange(coo_name, year)


# Estadísticas generales por año
yearly_stats <- refugees_by_origin_year %>%
  group_by(year) %>%
  summarise(
    total_global = sum(total_refugees, na.rm = TRUE),
    countries_active = n(),
    avg_per_country = mean(total_refugees, na.rm = TRUE),
    median_per_country = median(total_refugees, na.rm = TRUE),
    max_single_country = max(total_refugees, na.rm = TRUE),
    .groups = "drop"
  )
gt::gt(yearly_stats) %>%
  gt::tab_header(title = "Estadísticas Anuales Globales de Refugiados") %>%
  gt::cols_label(
    total_global = "Total Global",
    countries_active = "Países Activos",
    avg_per_country = "Media por País",
    median_per_country = "Mediana por País",
    max_single_country = "Máximo por País"
  ) %>%
  gt::fmt_number(columns = everything(), decimals = 0, sep_mark = ".") %>%
  gt::fmt_number(columns = c(year), decimals = 0, sep_mark = "") %>%
  gt::tab_spanner(label = "Estadísticas", columns = everything())



p1 <- ggplot(yearly_stats, aes(x = year, y = total_global)) +
  geom_line() + geom_point() +
  labs(title = "Refugiados totales", x = "Año", y = "") +
  scale_y_continuous(labels = scales::label_number(
    big.mark = ".", decimal_mark = ",", scale = 1/1000000, suffix = "M")) +
  theme_minimal()


p1

#- 4) PAISES -----------------------------------

#- Top 15 países de origen por total de refugiados
top_origin_countries <- refugees_by_origin_year %>%
  group_by(coo_name) %>%
  summarise(
    total_historical = sum(total_refugees, na.rm = TRUE),
    years_active = n(),
    avg_per_year = mean(total_refugees, na.rm = TRUE),
    max_single_year = max(total_refugees, na.rm = TRUE),
    max_year = year[which.max(total_refugees)],
    .groups = "drop"
  ) %>%
  arrange(desc(total_historical)) %>%
  head(15)

gt::gt(top_origin_countries) %>%
  gt::tab_header(title = "Top 15 Países de Origen de Refugiados") %>%
  gt::cols_label(
    coo_name = "País de Origen",
    total_historical = "Total Histórico",
    years_active = "Años Activos",
    avg_per_year = "Media por Año",
    max_single_year = "Máximo en un Año",
    max_year = "Año del Máximo"
  ) %>%
  gt::fmt_number(columns = everything(), decimals = 0, sep_mark = ".") %>%
  gt::fmt_number(columns = c(max_year), decimals = 0, sep_mark = "") %>%
  gt::tab_spanner(label = "Estadísticas", columns = everything())

